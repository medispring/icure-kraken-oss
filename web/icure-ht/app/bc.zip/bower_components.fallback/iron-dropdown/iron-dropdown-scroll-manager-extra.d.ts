declare namespace Polymer {
  /**
   * IronDropdownScrollManager is deprecated, use IronScrollManager instead.
   */
  const IronDropdownScrollManager: typeof Polymer.IronScrollManager;
}
